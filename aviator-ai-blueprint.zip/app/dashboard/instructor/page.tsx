import { InstructorDashboard } from "@/components/dashboard/instructor/instructor-dashboard"

export default function InstructorPage() {
  return <InstructorDashboard />
}
