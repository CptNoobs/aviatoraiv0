"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { ArrowRight, CheckCircle, Plane } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"

export function BetaAccessCTA() {
  const { toast } = useToast()
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !email.includes("@")) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setIsSubmitting(false)
    setIsSubmitted(true)
    setEmail("")

    toast({
      title: "Success!",
      description: "You've been added to our early beta access list.",
    })
  }

  return (
    <section className="px-4 py-24">
      <div className="container max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="relative overflow-hidden rounded-xl border border-blue-500/20 bg-gradient-to-br from-blue-900/30 via-background to-indigo-900/30 p-8 text-center backdrop-blur-md md:p-12"
        >
          {/* Animated elements */}
          <div className="absolute inset-0 z-0">
            <div className="absolute left-10 top-10 h-40 w-40 animate-float-slow rounded-full border border-blue-500/10 opacity-30" />
            <div className="absolute right-10 bottom-10 h-60 w-60 animate-float rounded-full border border-indigo-500/10 opacity-30" />
            <div className="absolute left-1/2 top-1/2 h-80 w-80 -translate-x-1/2 -translate-y-1/2 transform animate-rotate-slow rounded-full border border-blue-500/10 opacity-20" />
          </div>

          <div className="relative z-10">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-blue-500/20 to-indigo-500/20">
              <Plane className="h-8 w-8 text-blue-400" />
            </div>

            <h2 className="mb-4 text-3xl font-bold text-white md:text-4xl">
              Join the <span className="text-gradient-blue">Early Beta Access</span>
            </h2>
            <p className="mb-8 text-lg text-blue-300/80">
              Be among the first pilots to experience Aviator AI and help shape the future of aviation training and
              operations.
            </p>

            <form
              onSubmit={handleSubmit}
              className="mx-auto mb-4 flex max-w-md flex-col space-y-3 sm:flex-row sm:space-x-3 sm:space-y-0"
            >
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-12 border-blue-500/20 bg-blue-900/10 text-white backdrop-blur-sm placeholder:text-blue-300/50 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/50"
                disabled={isSubmitting || isSubmitted}
              />
              <Button
                type="submit"
                size="lg"
                className="h-12 btn-blue-glow px-8 text-white"
                disabled={isSubmitting || isSubmitted}
              >
                {isSubmitting ? "Joining..." : isSubmitted ? "Joined!" : "Get Early Access"}
                {!isSubmitting && !isSubmitted && <ArrowRight className="ml-2 h-4 w-4" />}
                {isSubmitted && <CheckCircle className="ml-2 h-4 w-4" />}
              </Button>
            </form>

            <p className="text-sm text-blue-300/60">
              No credit card required. Limited spots available for beta testers.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
