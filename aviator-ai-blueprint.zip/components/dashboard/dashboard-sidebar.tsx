"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Cloud, GraduationCap, Home, Plane, Users } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

export function DashboardSidebar() {
  const pathname = usePathname()

  const routes = [
    {
      name: "Overview",
      href: "/dashboard",
      icon: Home,
    },
    {
      name: "Student Dashboard",
      href: "/dashboard/student",
      icon: GraduationCap,
    },
    {
      name: "Instructor Dashboard",
      href: "/dashboard/instructor",
      icon: Users,
    },
    {
      name: "Weather",
      href: "/dashboard/weather",
      icon: Cloud,
    },
  ]

  return (
    <div className="flex h-full w-64 flex-col border-r border-border bg-card">
      <div className="flex h-14 items-center border-b border-border px-4">
        <Plane className="mr-2 h-5 w-5 text-primary" />
        <span className="font-semibold">Aviator AI Dashboard</span>
      </div>

      <div className="flex-1 overflow-auto py-2">
        <nav className="grid gap-1 px-2">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground",
                pathname === route.href ? "bg-accent text-accent-foreground" : "text-muted-foreground",
              )}
            >
              <route.icon className="h-4 w-4" />
              {route.name}
            </Link>
          ))}
        </nav>
      </div>

      <div className="border-t border-border p-4">
        <Button variant="outline" className="w-full justify-start">
          <Plane className="mr-2 h-4 w-4" />
          Launch Flight
        </Button>
      </div>
    </div>
  )
}
