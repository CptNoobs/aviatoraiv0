"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

export function ScrollProgress() {
  const [scrollProgress, setScrollProgress] = useState(0)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      // Calculate how far down the page the user has scrolled
      const windowHeight = document.documentElement.scrollHeight - window.innerHeight
      const scrolled = window.scrollY / windowHeight

      setScrollProgress(scrolled)

      // Only show progress bar after scrolling past hero section and into the AI Academy section
      const academySection = document.getElementById("pillar-academy")
      if (academySection && window.scrollY >= academySection.offsetTop - window.innerHeight / 2) {
        setIsVisible(true)
      } else {
        setIsVisible(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  if (!isVisible) return null

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed top-16 left-0 z-50 h-1 w-full bg-blue-900/20"
    >
      <motion.div className="h-full bg-blue-500" style={{ width: `${scrollProgress * 100}%` }} />
    </motion.div>
  )
}
