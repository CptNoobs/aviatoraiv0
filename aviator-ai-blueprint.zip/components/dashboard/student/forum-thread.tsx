"use client"

import { useState } from "react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { MessageSquare, ThumbsUp } from "lucide-react"

export function ForumThread() {
  const [newComment, setNewComment] = useState("")
  const [comments, setComments] = useState(forumData)

  const handleAddComment = () => {
    if (!newComment.trim()) return

    const newCommentObj = {
      id: comments.length + 1,
      author: "You",
      avatar: "U",
      content: newComment,
      timestamp: "Just now",
      likes: 0,
      replies: [],
    }

    setComments([...comments, newCommentObj])
    setNewComment("")
  }

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        {comments.map((comment) => (
          <Card key={comment.id} className="overflow-hidden">
            <CardHeader className="bg-muted/30 pb-3">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback>{comment.avatar}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-base">{comment.author}</CardTitle>
                  <p className="text-xs text-muted-foreground">{comment.timestamp}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-4">
              <p>{comment.content}</p>
            </CardContent>
            <CardFooter className="flex items-center justify-between border-t border-border pt-3">
              <div className="flex items-center gap-4">
                <Button variant="ghost" size="sm" className="h-8 gap-1 px-2">
                  <ThumbsUp className="h-4 w-4" />
                  <span>{comment.likes}</span>
                </Button>
                <Button variant="ghost" size="sm" className="h-8 gap-1 px-2">
                  <MessageSquare className="h-4 w-4" />
                  <span>{comment.replies.length}</span>
                </Button>
              </div>
              <Button variant="ghost" size="sm">
                Reply
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="space-y-3">
        <Textarea
          placeholder="Add your comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          className="min-h-[100px] resize-none"
        />
        <Button onClick={handleAddComment} disabled={!newComment.trim()}>
          Post Comment
        </Button>
      </div>
    </div>
  )
}

const forumData = [
  {
    id: 1,
    author: "Jane Smith",
    avatar: "JS",
    content:
      "Has anyone used the new weather prediction feature? I'm finding it much more accurate than ForeFlight for local conditions.",
    timestamp: "2 hours ago",
    likes: 12,
    replies: [
      {
        id: 101,
        author: "Mark Johnson",
        content: "Yes! It's been spot on for me too. Especially for detecting microbursts.",
        timestamp: "1 hour ago",
      },
    ],
  },
  {
    id: 2,
    author: "Robert Chen",
    avatar: "RC",
    content:
      "I'm struggling with the crosswind landing calculations in the simulator. Any tips or resources that might help?",
    timestamp: "Yesterday",
    likes: 5,
    replies: [],
  },
]
