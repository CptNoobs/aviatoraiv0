import { StudentDashboard } from "@/components/dashboard/student/student-dashboard"

export default function StudentPage() {
  return <StudentDashboard />
}
