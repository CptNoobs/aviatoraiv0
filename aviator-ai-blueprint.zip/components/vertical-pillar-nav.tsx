"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { BookOpen, Cloud, Plane } from "lucide-react"

interface VerticalPillarNavProps {
  activePillar: string
  setActivePillar: (pillar: string) => void
}

export function VerticalPillarNav({ activePillar, setActivePillar }: VerticalPillarNavProps) {
  const [mounted, setMounted] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setMounted(true)

    const handleScroll = () => {
      // Only show the pillar nav after scrolling past hero section
      const academySection = document.getElementById("pillar-academy")
      if (academySection && window.scrollY >= academySection.offsetTop - window.innerHeight / 2) {
        setIsVisible(true)
      } else {
        setIsVisible(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  if (!mounted || !isVisible) return null

  const pillars = [
    { id: "academy", icon: BookOpen, label: "AI Academy" },
    { id: "weather", icon: Cloud, label: "Weather Intelligence" },
    { id: "copilot", icon: Plane, label: "AI Co-Pilot Ops" },
  ]

  return (
    <div className="fixed right-6 top-1/2 z-30 hidden -translate-y-1/2 flex-col items-center space-y-6 md:flex">
      {pillars.map((pillar) => {
        const Icon = pillar.icon
        const isActive = activePillar === pillar.id

        return (
          <motion.button
            key={pillar.id}
            onClick={() => {
              setActivePillar(pillar.id)
              const element = document.getElementById(`pillar-${pillar.id}`)
              if (element) {
                element.scrollIntoView({ behavior: "smooth" })
              }
            }}
            className="group relative flex items-center"
            whileHover={{ scale: 1.1 }}
            transition={{ duration: 0.2 }}
          >
            <div
              className={`flex h-12 w-12 items-center justify-center rounded-full backdrop-blur-sm transition-all duration-300 ${
                isActive ? "bg-blue-500 text-white" : "bg-blue-900/20 text-blue-300 hover:bg-blue-800/30"
              }`}
            >
              <Icon className="h-5 w-5" />
            </div>
            <div
              className={`absolute right-full mr-3 whitespace-nowrap rounded-md px-2 py-1 text-sm font-medium transition-all duration-300 ${
                isActive
                  ? "bg-blue-500 text-white opacity-100"
                  : "bg-blue-900/20 text-blue-300 opacity-0 group-hover:opacity-100"
              }`}
            >
              {pillar.label}
            </div>
            <div
              className={`absolute left-full ml-3 h-1 w-8 rounded-full transition-all duration-300 ${
                isActive ? "bg-blue-500" : "bg-blue-900/20"
              }`}
            />
          </motion.button>
        )
      })}
    </div>
  )
}
