import { WeatherDashboard } from "@/components/dashboard/weather/weather-dashboard"

export default function WeatherPage() {
  return <WeatherDashboard />
}
